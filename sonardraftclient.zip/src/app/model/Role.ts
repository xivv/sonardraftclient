export enum Role {
    TOP,
    JUNGLE,
    MID,
    BOTTOM,
    SUPPORT
}
