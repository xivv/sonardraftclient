export interface Character {
    name: string;
    priority?: number;
    priorities?: Character[];
}
