import { Team } from './Team';

export interface Draft {
    blue: Team;
    red: Team;
}
